package dev.lelonio.square.ui.components

import androidx.compose.foundation.layout.height
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import dev.lelonio.square.ui.theme.InstrumentSerif
import dev.lelonio.square.ui.theme.Ink

/**
 * A page title, set in Waves' display serif.
 *
 * Square drew these in right-angled capitals; Waves sets them in sentence case
 * in Instrument Serif, already shipped for artist pages, so the same face
 * names the app, the tabs and the artists. The signature is unchanged so that
 * every tab header keeps calling it as before.
 *
 * [height] is still the old capitals' measure; the serif's size is taken from
 * it, which keeps the header's row exactly as tall as it was.
 */
@Composable
fun SquareTitle(
    text: String,
    height: Dp,
    modifier: Modifier = Modifier,
    color: Color = Ink,
) {
    val size = with(LocalDensity.current) { (height * 2.35f).toSp() }
    Text(
        text,
        modifier = modifier.semantics { heading() },
        color = color,
        fontFamily = InstrumentSerif,
        fontSize = size,
        lineHeight = size,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
    )
}
